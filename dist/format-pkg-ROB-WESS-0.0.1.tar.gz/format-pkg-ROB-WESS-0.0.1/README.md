# python-format-module
Small package to help with formatting and error handling
